/*
 * TimerTest.c
 *
 * Created: 3/12/2019 3:59:53 PM
 * Author : cookna1
 */ 

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

//#define PROBLEM_1
//#define PROBLEM_2
#define PROBLEM_3

unsigned char sigHigh = 1;



#ifdef PROBLEM_1
int main(void)
{
	
	//Period 333.33 ms, on-time = 75 ms
	TCCR1A = 0x00;
	
	//configure match register
	OCR1A = 4688; // 75 ms
	
	//setup initial output state
	DDRB = 0x80;
	PORTB |= 80;
	
	//enable interrupt
	TIMSK1 = 0x02;
	
	//start the timer
	sei();
	
	TCCR1B = 0x04; // clk/256 from prescalar-starts the timer running
	
	while (1)
	
	{
		
		
		
	}
	

}

ISR(TIMER1_COMPA_vect){
	
	//PORTB ^= 0x80;
	
	if(sigHigh){
		OCR1A += 16144;
		sigHigh =0;
		PORTB = 0x00;
	}
	else{
		OCR1A += 4688;
		sigHigh = 1;
		PORTB =  0x80;
	}
}
#endif



#ifdef PROBLEM_2
int main(void)
{
	
	//Period 333.33 ms, on-time = 75 ms
	TCCR1A = 0x00;
	
	//configure match register
	OCR1A = 4688; // 75 ms
	
	//setup initial output state
	DDRB = 0x80;
	PORTB |= 80;
	
	//enable interrupt
	TIMSK1 = 0x02;
	
	//start the timer
	sei();
	
	TCCR1B = 0x04; // clk/256 from prescalar-starts the timer running
	
	ICR1 = 20832; //TOP value - 333.33 ms or 20,832
	
	
	
	while (1){
		
		if(ICR1 <= OCR1A){
			OCR1A = 0;
			sigHigh = 1;
		}
		
	}
	

}

ISR(TIMER1_COMPA_vect){
	
	
	if(sigHigh){
		OCR1A += 16144;
		PORTB =  0x80;
		sigHigh =0;
	}
	else{
		OCR1A += 4688;
		sigHigh = 1;
		PORTB =  0x00;
	}
}

#endif

#ifdef PROBLEM_3
int main(void)
{
	
	//Period 333.33 ms, on-time = 75 ms
	TCCR1A = WGM00;

	//configure match register
	OCR1C = 8072; 
	ICR1 = 10416; //TOP value - 333.33 ms or 20,832
	//setup initial output state
	DDRB = 0x80;
	
	
	
	TCCR1B = 0x04; // clk/256 from prescalar-starts the timer running
	
	
	
	
	
	while (1)
	{
		//if()
	
		
		
	}
	

}



#endif