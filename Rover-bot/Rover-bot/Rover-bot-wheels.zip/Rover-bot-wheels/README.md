# Rover-bot


Rover-bot is an autonomous robot project for Embedded Systems by Andrew Thorp, Eli McGalliard, Nathan Cook, and James Wilson.

Below is a brief specification:

![Parts list](Part_Spec.png)

Software API:

![Top Level API](Robot_API.png)
