/*
 * time.h
 *
 * Created: 4/30/2019 7:20:44 AM
 *  Author: thorpah
 */ 


#ifndef TIME_H_
#define TIME_H_

int timerInitialized(void);
unsigned long getTime(void);
void setTime();

#endif /* TIME_H_ */